﻿using System;
using System.Collections.Generic;
using System.Text;
namespace _01_ClassSquare
{
    internal class Square
    {
        int side;
        public int Side 
        { 
            get { return side; } 
            set { side = value;} 
        }
    }
}
